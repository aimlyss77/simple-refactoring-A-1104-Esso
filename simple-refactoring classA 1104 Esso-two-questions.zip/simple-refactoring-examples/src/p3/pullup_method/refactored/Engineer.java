package p3.pullup_method.refactored;

public class Engineer extends Employee {
}
